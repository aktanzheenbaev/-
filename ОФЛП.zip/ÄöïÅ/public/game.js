const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');
const minimap = document.getElementById('minimap');
const mctx = minimap.getContext('2d');
const leaderboard = document.getElementById('leaderboard');

const startBtn = document.getElementById('startBtn');
const overlay = document.getElementById('overlay');
const gameOver = document.getElementById('gameOver');
const nameInput = document.getElementById('nameInput');
const skinSelect = document.getElementById('skinSelect');

minimap.width = 200;
minimap.height = 200;

let ws;
let myId = null;
let state = { players: [], foods: [] };
let camera = { x: 0, y: 0 };
let isDead = false;

function resize() {
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
}
window.addEventListener('resize', resize);
resize();

function connect() {
    const protocol = location.protocol === 'https:' ? 'wss://' : 'ws://';
    ws = new WebSocket(protocol + location.host);

    ws.onopen = () => {
        ws.send(JSON.stringify({
            type: 'join',
            name: nameInput.value || "Player",
            color: skinSelect.value || "#ff00ff"
        }));
    };

    ws.onmessage = (e) => {
        const data = JSON.parse(e.data);

        if (data.type === 'init') {
            myId = data.id;
            overlay.style.display = 'none';
        }

        if (data.type === 'state') {
            state = data.state;
        }

        // 💀 СМЕРТЬ ТОЛЬКО ЗДЕСЬ!
        if (data.type === 'dead') {
            isDead = true;
            gameOver.style.display = "flex";
        }
    };
}

startBtn.onclick = connect;

let mouseX = 0;
let mouseY = 0;

window.addEventListener('mousemove', (e) => {
    mouseX = e.clientX;
    mouseY = e.clientY;
});

// 🎮 управление
setInterval(() => {

    if (isDead) return;

    if (!ws || ws.readyState !== WebSocket.OPEN) return;

    const dx = mouseX - canvas.width / 2;
    const dy = mouseY - canvas.height / 2;

    ws.send(JSON.stringify({
        type: 'target',
        angle: Math.atan2(dy, dx)
    }));

}, 1000/30);

function updateCamera() {
    const me = state.players.find(p => p.id === myId);
    if (me) {
        camera.x += (me.x - canvas.width/2 - camera.x) * 0.1;
        camera.y += (me.y - canvas.height/2 - camera.y) * 0.1;
    }
}

function draw() {
    requestAnimationFrame(draw);

    if (!state.players) return;

    updateCamera();

    ctx.fillStyle = "#050010";
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    ctx.save();
    ctx.translate(-camera.x, -camera.y);

    ctx.strokeStyle = "#ff00ff";
    ctx.strokeRect(0,0,2000,2000);

    // еда
    state.foods.forEach(f => {
        ctx.beginPath();
        ctx.arc(f.x, f.y, 5, 0, Math.PI*2);
        ctx.fillStyle = "#00ffff";
        ctx.fill();
    });

    // игроки
    state.players.forEach(p => {

        if (p.id === myId && isDead) return;

        p.history.forEach((seg,i) => {
            ctx.beginPath();
            ctx.arc(seg.x, seg.y, 10, 0, Math.PI*2);
            ctx.fillStyle = i === 0 ? "#ffffff" : p.color;
            ctx.fill();
        });

        ctx.globalAlpha = 0.7;
        ctx.fillStyle = "white";
        ctx.fillText(p.name || "Player", p.x, p.y - 20);
        ctx.globalAlpha = 1;
    });

    ctx.restore();

    // миникарта
    mctx.fillStyle = "black";
    mctx.fillRect(0,0,200,200);

    const scale = 200 / 2000;

    state.players.forEach(p => {
        mctx.fillStyle = p.id === myId ? "#ff00ff" : "#fff";
        mctx.fillRect(p.x * scale, p.y * scale, 4, 4);
    });

    // рейтинг
    const sorted = [...state.players].sort((a,b)=>b.score-a.score);

    leaderboard.innerHTML =
        "<b>TOP</b><br>" +
        sorted.slice(0,5).map(p => `${p.name}: ${p.score}`).join("<br>");
}

draw();