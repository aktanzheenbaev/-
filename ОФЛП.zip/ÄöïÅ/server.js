const express = require('express');
const http = require('http');
const WebSocket = require('ws');
const path = require('path');

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

app.use(express.static(path.join(__dirname, 'public')));

const MAP_SIZE = 2000;
const FOOD_COUNT = 200;
const BOT_COUNT = 5;

const BOT_NAMES = ["Alex","Max","Leo","Nova","Shadow","Ghost","Pixel","Viper"];

let players = {};
let foods = [];

// 🍎 еда
function spawnFood() {
    foods.push({
        x: Math.random() * MAP_SIZE,
        y: Math.random() * MAP_SIZE
    });
}

// 🤖 бот
function spawnBot() {
    const id = "bot_" + Math.random();

    players[id] = {
        id,
        name: BOT_NAMES[Math.floor(Math.random()*BOT_NAMES.length)] || "Bot",
        isBot: true,
        x: Math.random() * MAP_SIZE,
        y: Math.random() * MAP_SIZE,
        angle: Math.random() * Math.PI * 2,
        targetAngle: Math.random() * Math.PI * 2,
        history: [],
        score: 20,
        color: `hsl(${Math.random()*360},100%,50%)`
    };

    for (let i = 0; i < 20; i++) {
        players[id].history.push({x: players[id].x, y: players[id].y});
    }
}

// старт
for (let i = 0; i < FOOD_COUNT; i++) spawnFood();
for (let i = 0; i < BOT_COUNT; i++) spawnBot();

// подключение
wss.on('connection', (ws) => {
    const id = Math.random().toString(36).substr(2, 9);
    ws.playerId = id;

    players[id] = {
        id,
        name: "Player",
        isBot: false,
        x: Math.random() * MAP_SIZE,
        y: Math.random() * MAP_SIZE,
        angle: 0,
        targetAngle: 0,
        history: [],
        score: 20,
        color: "#ff00ff"
    };

    for (let i = 0; i < 20; i++) {
        players[id].history.push({x: players[id].x, y: players[id].y});
    }

    ws.send(JSON.stringify({ type: 'init', id }));

    ws.on('message', (msg) => {
        let data;

        try {
            data = JSON.parse(msg);
        } catch {
            return;
        }

        const player = players[id];
        if (!player) return;

        if (data.type === 'join') {
            player.name = data.name || "Player";
            player.color = data.color || "#ff00ff";
        }

        if (data.type === 'target') {
            if (typeof data.angle === 'number') {
                player.targetAngle = data.angle;
            }
        }
    });

    ws.on('close', () => delete players[id]);
});

// игровой цикл
setInterval(() => {

    // движение
    for (let id in players) {
        const p = players[id];

        // 🤖 БОТЫ УБЕГАЮТ
        if (p.isBot) {
            let danger = null;

            for (let id2 in players) {
                if (id2 === p.id) continue;

                const other = players[id2];

                const dx = other.x - p.x;
                const dy = other.y - p.y;
                const dist = dx*dx + dy*dy;

                if (dist < 40000) {
                    danger = other;
                    break;
                }
            }

            if (danger) {
                const dx = p.x - danger.x;
                const dy = p.y - danger.y;
                p.targetAngle = Math.atan2(dy, dx);
            } else if (Math.random() < 0.02) {
                p.targetAngle += (Math.random() - 0.5);
            }
        }

        p.angle += (p.targetAngle - p.angle) * 0.15;

        p.x += Math.cos(p.angle) * 3;
        p.y += Math.sin(p.angle) * 3;

        p.x = Math.max(0, Math.min(MAP_SIZE, p.x));
        p.y = Math.max(0, Math.min(MAP_SIZE, p.y));

        p.history.unshift({x: p.x, y: p.y});
        while (p.history.length > p.score) p.history.pop();
    }

    // 💀 СТОЛКНОВЕНИЯ (ЧИСТО)
    const toDelete = new Set();

    for (let id in players) {
        const p = players[id];

        for (let otherId in players) {
            if (id === otherId) continue;

            const other = players[otherId];

            // голова в тело
            for (let i = 2; i < other.history.length; i++) {
                const seg = other.history[i];

                const dx = p.x - seg.x;
                const dy = p.y - seg.y;

                if (dx*dx + dy*dy < 400) {
                    p.history.forEach(s => foods.push({ x: s.x, y: s.y }));
                    toDelete.add(id);
                    break;
                }
            }

            if (toDelete.has(id)) break;

            // голова в голову
            const dx = p.x - other.x;
            const dy = p.y - other.y;

            if (dx*dx + dy*dy < 400) {
                toDelete.add(id);
                toDelete.add(otherId);
            }
        }
    }

    // уведомление
    wss.clients.forEach(client => {
        if (client.readyState !== WebSocket.OPEN) return;

        if (toDelete.has(client.playerId)) {
            client.send(JSON.stringify({ type: 'dead' }));
        }
    });

    // удаление
    toDelete.forEach(id => delete players[id]);

    // еда
    for (let id in players) {
        const p = players[id];

        for (let i = foods.length - 1; i >= 0; i--) {
            const f = foods[i];
            const dx = p.x - f.x;
            const dy = p.y - f.y;

            if (dx*dx + dy*dy < 400) {
                foods.splice(i, 1);
                p.score += 3;
                spawnFood();
            }
        }
    }

    const state = {
        players: Object.values(players),
        foods
    };

    const data = JSON.stringify({ type: 'state', state });

    wss.clients.forEach(c => {
        if (c.readyState === WebSocket.OPEN) {
            c.send(data);
        }
    });

}, 1000/30);

// запуск
server.listen(3000, () => {
    console.log("http://localhost:3000");
});